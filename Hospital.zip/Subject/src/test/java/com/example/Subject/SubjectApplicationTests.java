package com.example.Subject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
